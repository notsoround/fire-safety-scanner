# 🔥 Fire Safety Scanner

**AI-Powered Fire Extinguisher Inspection Management System**

A modern web application that uses AI to analyze fire extinguisher inspection tags, track maintenance schedules, and manage compliance records. Built with React, FastAPI, and MongoDB.

![Fire Safety Scanner](https://images.unsplash.com/photo-1660165458059-57cfb6cc87e5?w=800&h=400&fit=crop)

---

## 🌟 Features

### 🤖 **AI-Powered Analysis**
- **Gemini 2.5 Pro Integration**: Advanced AI analysis of fire extinguisher inspection tags
- **Image Recognition**: Upload photos or use camera to capture inspection tags
- **Structured Data Extraction**: Automatically extracts dates, condition, type, and maintenance notes

### ✏️ **Manual Editing**
- **Edit AI Results**: Manually correct or update analysis results
- **Structured Fields**: Edit inspection dates, extinguisher type, condition, maintenance notes
- **Real-time Updates**: Changes are immediately saved and reflected in alerts

### 📱 **User Experience**
- **Camera Integration**: Take photos directly within the app
- **Location Tracking**: Tag each inspection with specific location
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Glassmorphism UI**: Modern, futuristic interface design

### 💳 **Subscription Management**
- **Stripe Integration**: Secure payment processing
- **Multiple Tiers**: Basic ($29.99), Professional ($79.99), Enterprise ($199.99)
- **Usage Tracking**: Monitor inspection counts and remaining quota

### 🔔 **Smart Alerts**
- **Due Date Tracking**: Automatic alerts for inspections due within 30 days
- **Dashboard Warnings**: Visual indicators for overdue inspections
- **Maintenance Flags**: Highlight extinguishers requiring attention

### 🔗 **Workflow Integration**
- **N8n Webhooks**: Automatically send inspection data to external workflows
- **API Access**: RESTful API for third-party integrations
- **Data Export**: Complete inspection history and reporting

---

## 🏗️ System Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│    Frontend     │────│    Backend      │────│    MongoDB      │
│  React + Vite   │    │    FastAPI      │    │   Database      │
│  Tailwind CSS   │    │    Python       │    │   Collections   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                        │                      │
         │                        ▼                      │
         │              ┌─────────────────┐              │
         │              │   OpenRouter    │              │
         │              │  Gemini 2.5 Pro │              │
         │              └─────────────────┘              │
         │                        │                      │
         ▼                        ▼                      ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│     Nginx       │    │     Stripe      │    │      N8n        │
│  Reverse Proxy  │    │   Payments      │    │   Webhooks      │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

---

## 📂 Project Structure

```
fire-safety-scanner/
├── 📁 backend/                 # FastAPI backend application
│   ├── server.py              # Main FastAPI server with all endpoints
│   ├── requirements.txt       # Python dependencies
│   └── .env                   # Backend environment variables
│
├── 📁 frontend/               # React frontend application  
│   ├── 📁 src/
│   │   ├── App.js             # Main React component
│   │   ├── App.css            # Application styles
│   │   ├── index.js           # React entry point
│   │   └── index.css          # Global styles
│   ├── 📁 public/
│   │   └── index.html         # HTML template
│   ├── package.json           # Node.js dependencies
│   ├── tailwind.config.js     # Tailwind CSS configuration
│   └── .env                   # Frontend environment variables
│
├── 📁 docker/                 # Docker configuration files
│   ├── nginx.conf             # Nginx configuration
│   ├── nginx-ssl.conf         # SSL-enabled Nginx config
│   └── supervisord.conf       # Process management
│
├── 📁 sample_data/            # Sample data for development/demo
│   └── init-sample-data.js    # MongoDB initialization script
│
├── 🐳 Dockerfile              # Multi-stage Docker build
├── 🐳 docker-compose.yml      # Development deployment
├── 🐳 docker-compose.prod.yml # Production deployment with SSL
├── 🚀 quick-deploy.sh         # One-command deployment script
├── 📖 DEPLOYMENT.md           # Detailed deployment guide
├── 🔧 .env.example            # Environment variables template
└── 📋 README.md               # This file
```

---

## 🚀 Quick Start

### 1. **Download & Extract**
```bash
# Download the export package
# Extract it
tar -xzf fire-safety-scanner-export.tar.gz
cd fire-safety-scanner
```

### 2. **Configure Environment**
```bash
# Copy environment template
cp .env.example .env

# Edit with your API keys
nano .env
```

### 3. **Deploy with Docker**
```bash
# Make deploy script executable
chmod +x quick-deploy.sh

# Run the deployment script
./quick-deploy.sh
```

### 4. **Access Your Application**
- **Frontend**: http://your-server-ip
- **Backend API**: http://your-server-ip:8001/api
- **API Docs**: http://your-server-ip:8001/docs

---

## 🔑 Required API Keys

### **OpenRouter API Key** 
- **Purpose**: AI analysis using Gemini 2.5 Pro
- **Get it**: https://openrouter.ai/keys
- **Cost**: Pay-per-use (typically ~$0.01 per analysis)

### **Stripe API Key**
- **Purpose**: Payment processing for subscriptions
- **Get it**: https://dashboard.stripe.com/apikeys
- **Types**: Use test keys for development, live keys for production

### **N8n Webhook URL** *(Optional)*
- **Purpose**: Automated workflow integration
- **Get it**: Create webhook trigger in N8n workflow
- **Use**: Send inspection data to external systems

---

## 💾 Database Schema

### **Users Collection**
```javascript
{
  id: "user-uuid",
  email: "user@example.com",
  name: "User Name",
  picture: "https://profile-image-url",
  subscription_active: true,
  inspections_remaining: 45,
  created_at: ISODate
}
```

### **Inspections Collection**
```javascript
{
  id: "inspection-uuid",
  user_id: "user-uuid",
  location: "Building A - Floor 2",
  image_base64: "base64-encoded-image",
  inspection_date: ISODate,
  due_date: ISODate,
  status: "analyzed",
  gemini_response: "{JSON with analysis results}",
  notes: "Additional user notes",
  created_at: ISODate,
  updated_at: ISODate
}
```

### **Sessions Collection**
```javascript
{
  session_id: "emergent-session-id",
  user_id: "user-uuid", 
  session_token: "internal-session-token",
  expires_at: ISODate,
  created_at: ISODate
}
```

---

## 🔌 API Endpoints

### **Authentication**
- `POST /api/auth/session` - Create session from Emergent Auth
- `GET /api/auth/profile` - Get current user profile

### **Inspections**
- `POST /api/inspections` - Create new inspection with AI analysis
- `GET /api/inspections` - Get user's inspection history
- `PUT /api/inspections/{id}` - Update inspection data (manual editing)
- `GET /api/inspections/due` - Get inspections due within 30 days

### **Payments**
- `GET /api/packages` - Get available subscription packages
- `POST /api/payments/checkout/session` - Create Stripe checkout session
- `GET /api/payments/checkout/status/{session_id}` - Check payment status
- `POST /api/webhook/stripe` - Handle Stripe webhooks

### **Utility**
- `GET /api/health` - Health check endpoint

---

## 🎨 UI Components & Features

### **Login Page**
- Emergent Auth integration
- Glassmorphism design with gradient background
- Responsive layout

### **Dashboard**
- Inspection statistics (remaining, total, due soon)
- Due inspection alerts with visual indicators
- Image upload interface (file picker + camera)
- Location input and notes fields

### **Inspection History**
- Grid layout with inspection cards
- Image thumbnails and analysis results
- **Edit functionality** with structured form fields
- Status indicators and dates

### **Subscription Page**
- Three-tier pricing display
- Stripe checkout integration
- Payment status tracking

### **Manual Editing Interface**
- **Structured form fields**:
  - Date pickers for inspection/due dates
  - Dropdown for condition (Good/Fair/Poor)
  - Text inputs for type and maintenance notes
  - Checkbox for "requires attention"
  - Location and additional notes
- **Save/Cancel buttons**
- **Real-time updates** to database and alerts

---

## 🛠️ Development

### **Local Development Setup**
```bash
# Backend
cd backend
pip install -r requirements.txt
python -m uvicorn server:app --host 0.0.0.0 --port 8001 --reload

# Frontend (new terminal)
cd frontend
yarn install
yarn start
```

### **Environment Variables**

**Backend (.env)**
```env
MONGO_URL=mongodb://localhost:27017
DB_NAME=fire_safety_db
OPENROUTER_API_KEY=your_key_here
STRIPE_API_KEY=your_key_here
N8N_WEBHOOK_URL=your_webhook_url
```

**Frontend (.env)**
```env
REACT_APP_BACKEND_URL=http://localhost:8001
```

---

## 🔧 Configuration

### **Subscription Packages**
Defined in `backend/server.py`:
```python
PAYMENT_PACKAGES = {
    "basic": {"name": "Basic Plan", "price": 29.99, "inspections_included": 50},
    "professional": {"name": "Professional Plan", "price": 79.99, "inspections_included": 200},
    "enterprise": {"name": "Enterprise Plan", "price": 199.99, "inspections_included": 1000}
}
```

### **AI Analysis Prompt**
The system prompt for Gemini 2.5 Pro analysis:
- Extracts last inspection date, next due date
- Identifies extinguisher type (ABC, CO2, Class K, etc.)
- Assesses condition (Good/Fair/Poor)
- Notes maintenance requirements
- Flags items requiring attention

---

## 🚨 Troubleshooting

### **Common Issues**

**🔴 Application not accessible**
- Check if Docker containers are running: `docker-compose ps`
- Verify ports 80 and 8001 are open in firewall
- Check logs: `docker-compose logs`

**🔴 AI analysis failing**
- Verify OPENROUTER_API_KEY is correct
- Check OpenRouter account has sufficient credits
- View backend logs: `docker-compose logs backend`

**🔴 Payment issues**
- Ensure STRIPE_API_KEY is correct (test vs live)
- Check Stripe dashboard for webhook events
- Verify webhook URLs are accessible

**🔴 Database connection issues**
- Ensure MongoDB container is running
- Check MONGO_URL configuration
- Verify database initialization completed

### **Log Locations**
```bash
# All service logs
docker-compose logs

# Specific service logs  
docker-compose logs backend
docker-compose logs mongo

# Real-time logs
docker-compose logs -f
```

---

## 📊 Sample Data

The application includes sample data for demonstration:

- **2 demo users** with different subscription levels
- **5 sample inspections** with various conditions:
  - Building A - Main Entrance (Good condition, ABC type)
  - Kitchen Area (Fair condition, requires attention)
  - Loading Dock (Good condition, CO2 type)
  - Electrical Room (Poor condition, urgent service needed)
  - Parking Garage (Good condition, Foam type)

Sample data is automatically loaded when using Docker deployment.

---

## 🔒 Security Features

- **Session-based authentication** with token validation
- **Environment variable isolation** for sensitive data
- **CORS protection** with configurable origins
- **Input validation** using Pydantic models
- **SQL injection prevention** through MongoDB
- **XSS protection** via React's built-in sanitization
- **HTTPS support** for production deployments

---

## 📈 Performance & Scalability

- **Docker containerization** for consistent deployments
- **Nginx reverse proxy** for efficient request handling
- **MongoDB indexing** on user_id and due_date fields
- **Base64 image storage** for simplified deployment
- **Lazy loading** for inspection history
- **Responsive design** for mobile optimization

---

## 🔄 Updates & Maintenance

### **Application Updates**
```bash
# Pull latest changes
docker-compose pull

# Rebuild and restart
docker-compose up -d --build
```

### **Database Backup**
```bash
# Create backup
docker exec -i container_name mongodump --db fire_safety_db --archive > backup.archive

# Restore backup
docker exec -i container_name mongorestore --db fire_safety_db --archive < backup.archive
```

### **SSL Certificate Renewal** *(for production)*
```bash
# Renew Let's Encrypt certificates
sudo certbot renew

# Restart nginx
docker-compose restart
```

---

## 📞 Support & Documentation

- **📖 Deployment Guide**: See `DEPLOYMENT.md` for detailed setup instructions
- **🐳 Docker Configuration**: Multi-stage builds with production optimizations
- **🚀 Quick Deploy**: Use `quick-deploy.sh` for one-command deployment
- **📋 API Documentation**: Available at `/docs` endpoint when running

---

## 🎯 Use Cases

### **Fire Safety Companies**
- Manage client inspections across multiple locations
- Generate compliance reports and documentation
- Track maintenance schedules and due dates
- Automate workflow integration with existing systems

### **Facility Managers**
- Monitor fire safety equipment across buildings
- Ensure compliance with safety regulations
- Track inspection history and maintenance records
- Receive alerts for overdue inspections

### **Inspection Services**
- Streamline inspection documentation process
- Use AI to reduce manual data entry errors
- Provide professional reports to clients
- Manage multiple client accounts and subscriptions

---

## ⚡ Key Benefits

- **🕐 Time Savings**: AI analysis reduces manual data entry by 90%
- **📊 Accuracy**: Structured data extraction eliminates transcription errors
- **🔔 Compliance**: Automated alerts ensure no missed inspections
- **📱 Mobility**: Camera integration for on-site inspections
- **✏️ Flexibility**: Manual editing ensures data accuracy
- **🔗 Integration**: Webhook support for existing workflows
- **💰 Cost-Effective**: Pay-per-use AI with flexible subscription tiers

---

*Built with ❤️ for fire safety professionals. Stay safe, stay compliant.*
